<?
if (!defined('ABSPATH')) {
    exit;
}
// Registering your Custom Post Type
unregister_post_type('confirmacionesdepago');
